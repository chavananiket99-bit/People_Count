document.querySelectorAll("li a.active").forEach((anchor) => {
  anchor.parentElement.classList.add("active");
});

$(document).ready(function () {
  $(".mobile-notif a").click(function () {
    $(".mobile-notif, .mobile-notif-cotainer").addClass("active").togglefade();
  });
  $(".close-notif").click(function () {
    $(".mobile-notif, .mobile-notif-cotainer")
      .removeClass("active")
      .togglefade();
  });
  $(".search-menu-li a").click(function () {
    $(".search-box, .search-menu-li").toggleClass("active").togglefade();
  });

  //////////////////////// new header start ////////////////////////
  var PUS = {};
  /*==========================================
                      :: slicknav
              ==========================================*/
  PUS.slicknav = function () {
    $(".main-menu").slicknav({
      allowParentLinks: true,
      prependTo: "#mobile-menu-wrap",
      label: "",
    });

    $(".mobile-menu-trigger").on("click", function (e) {
      $(".mobile-menu-container").addClass("menu-open");
      e.stopPropagation();
    });

    $(".mobile-menu-close").on("click", function (e) {
      $(".mobile-menu-container").removeClass("menu-open");
      e.stopPropagation();
    });
  };
  $(document).ready(function () {
    PUS.slicknav();
  });
  //////////////////////// new header end ////////////////////////
});
